/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loag;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author FnMoises
 */
public class login  extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        
        //-------------HEADER IMAGE-----------------
        Image image = new Image("images/uplog.jpg");
 
          //.setTop(btn);
        ImageView iv2 = new ImageView();
         iv2.setImage(image);
         iv2.setFitWidth(430);
         iv2.setPreserveRatio(true);
         iv2.setSmooth(true);
         iv2.setCache(true);
        
                
        //-------------END HEADER IMAGE-----------------
        
        //----------------LANGUAGE---------------------
        //Controles de la aplicacion.
       
        Label ingles = new Label("Nivel de Actividad");
        
        
        //------------------FORMS ---------------------
        TextField user= new TextField();
        user.setPromptText("USUARIO O CORREO ELECTRONICO"); 
        TextField pass= new TextField();
        pass.setPromptText("CONTRASEÑA"); 
        
        
        //----------------ENDS FORMS-------------------
        
        //-----------------BUTTONS VERITCAL---------------------
       Button btn= new Button("Iniciar sesión");
       Button forgotpas= new Button("¿Olvidaste tu contrsseña");
       forgotpas.setId("forgotpas"); 
       Button face= new Button("Iniciar con Facebook");
       face.setId("facebook"); 
       Button regist= new Button("Registrarse");
       regist.setId("registrarse"); 
        //-----------------BUTTONS HORIZONTAL languages---------------------
       Button ingls= new Button("Ingles");
       ingls.setId("languages"); 
       Button espal= new Button("Español");
       espal.setId("languages"); 
       Button mas= new Button("Más");
       mas.setId("languages");
       //-----------------END BUTTONS HORIZONTAL languages------------------
        
        //-----------------PRINT HEADER-------------------
        VBox topRoot = new VBox(iv2);
        //----------------END PRINT HEADER----------------
        
        //-----------------Layout down Header languages-------------
         FlowPane flow = new FlowPane();
         flow.getChildren().addAll(ingls,espal,mas);
         
        //-----------------End Layout down Header languages---------
        
        //Layout para la parte central.
        VBox centerRoot= new VBox(user,pass);
        centerRoot.setSpacing(20);
        centerRoot.setPadding(new Insets(0));
       
        
        
        //Show Buttons for part center down.
        AnchorPane  bottomRoot = new AnchorPane(btn,forgotpas,face,regist);
        
        
        
        //Layout principal, el cual contendra a los tres layouts anteriores.
        BorderPane mainRoot = new BorderPane();
        
        /*Al utilizar BorderPane como layout princiapl, debemos establecer 
        la posicion de nuestros layouts secundarios.*/
        mainRoot.setTop(topRoot);
        mainRoot.setTop(flow);// ----------------------------------------------------¿donde coloco los botones
        mainRoot.setCenter(centerRoot);
        mainRoot.setBottom(bottomRoot);
        
        //Establecemos la orientacion de los botones en el centro.
//        AnchorPane.setTopAnchor(btn, 1.0);
//        AnchorPane.setRightAnchor(btn, 1.0);
//        AnchorPane.setTopAnchor(forgotpas, 2.0);
//        AnchorPane.setRightAnchor(forgotpas, 2.0);
//        AnchorPane.setTopAnchor(face, 3.0);
//        AnchorPane.setRightAnchor(face, 3.0);
//        AnchorPane.setTopAnchor(regist, 4.0);
//        AnchorPane.setRightAnchor(regist, 4.0);
       
        
        
        //Creamos y asociamos las clases css para los controles.
        mainRoot.getStyleClass().add("main-root");
        topRoot.getStyleClass().add("top-root");
        centerRoot.getStyleClass().add("center-root");
        bottomRoot.getStyleClass().add("bottom-root");
        ingles.getStyleClass().add("Ingles");
        
        //Creamos nuestra escena y le agregamos el layout principal
        Scene scene = new Scene(mainRoot, 430, 700);
        //Vinculamos nuestro archivo css a nuestra escena.
        scene.getStylesheets().add("css/Estilo.css");
        
        primaryStage.setTitle("Login");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
}