/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loag;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author FnMoises
 */
public class login  extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        
        //-------------HEADER IMAGE-----------------
        Image image = new Image("images/uplog.jpg");
 
          //.setTop(btn);
        ImageView iv2 = new ImageView();
         iv2.setImage(image);
         iv2.setFitWidth(430);
         iv2.setPreserveRatio(true);
         iv2.setSmooth(true);
         iv2.setCache(true);
        
                
        //-------------END HEADER IMAGE-----------------
        
        //----------------LANGUAGE---------------------
        //Controles de la aplicacion.
       
        Label ingles = new Label("Nivel de Actividad");
        
        
        //------------------FORMS ---------------------
        TextField user= new TextField();
        user.setPromptText("USUARIO O CORREO ELECTRONICO"); 
        PasswordField pass= new PasswordField();
        pass.setPromptText("CONTRASEÑA"); 
        
        
        //----------------ENDS FORMS-------------------
        
        //-----------------BUTTONS VERITCAL---------------------
       Button btn= new Button("Iniciar sesión");
       Button forgotpas= new Button("¿Olvidaste tu contrsseña?");
       forgotpas.setId("forgotpas"); 
       Button face= new Button("Iniciar con Facebook");
       face.setId("facebook"); 
       Button regist= new Button("Registrarse");
       regist.setId("registrarse"); 
        //-----------------BUTTONS HORIZONTAL languages---------------------
       Button ingls= new Button("Ingles");
       ingls.setId("languages"); 
       Button espal= new Button("Español");
       espal.setId("languages"); 
       Button mas= new Button("Más");
       mas.setId("languages");
       //-----------------END BUTTONS HORIZONTAL languages------------------
        
        //-----------------Layout down Header languages-------------
         
         HBox lang = new HBox(ingls,espal,mas);
         
        //-----------------End Layout down Header languages---------
        
        //-----------------PRINT HEADER-------------------
        VBox topRoot = new VBox(iv2,lang);
        //----------------END PRINT HEADER----------------
        
        
        
        //-------------------PART DOWN FORM BUTTONS------------
//        VBox bottomRoot = new VBox(10);//Asignamos 10 pixeles de separacion entre los nodos
        VBox  bottomRoot = new VBox(10);
        bottomRoot.setPadding(new Insets(15)); //Agregamos un relleno de 15 pixeles para separarlo del borde de la ventana
        bottomRoot.getChildren().addAll(btn,forgotpas,face,regist);
        //Layout para la parte central.
        VBox centerRoot= new VBox(user,pass,bottomRoot);
        centerRoot.setSpacing(20);
        centerRoot.setPadding(new Insets(0));
         
        
        //Layout principal, el cual contendra a los tres layouts anteriores.
        BorderPane mainRoot = new BorderPane();
        
        /*Al utilizar BorderPane como layout princiapl, debemos establecer 
        la posicion de nuestros layouts secundarios.*/
        mainRoot.setTop(topRoot);
        mainRoot.setCenter(centerRoot);
//        mainRoot.setBottom(bottomRoot);
        
      
        
        
        //Creamos y asociamos las clases css para los controles.
        mainRoot.getStyleClass().add("");
        topRoot.getStyleClass().add("");
        centerRoot.getStyleClass().add("center-root");
        bottomRoot.getStyleClass().add("bottom-root");
        lang.getStyleClass().add("idiomas");
        ingles.getStyleClass().add("Ingles");
        
        //Creamos nuestra escena y le agregamos el layout principal
        Scene scene = new Scene(mainRoot, 430, 700);
        //Vinculamos nuestro archivo css a nuestra escena.
        scene.getStylesheets().add("css/Estilo.css");
        
        primaryStage.setTitle("Login");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
}